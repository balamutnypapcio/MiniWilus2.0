/*
 * timing.h
 *
 *  Created on: Nov 11, 2025
 *      Author: jakub
 */

#ifndef INC_TIMING_H_
#define INC_TIMING_H_

#include <stdint.h>
// Deklaracja naszej precyzyjnej funkcji opóźniającej
void MyDelay_ms(uint16_t ms);

// Deklaracja funkcji HAL_Delay jako "słabej" (weak) - to klucz do jej nadpisania
//void HAL_Delay(uint32_t Delay);

#endif /* INC_TIMING_H_ */
